# Model mixing

In this section we go over basic features of Bayesian model averaging and model mixing.

Good references are:

Could combine this section with the "Model selection"
