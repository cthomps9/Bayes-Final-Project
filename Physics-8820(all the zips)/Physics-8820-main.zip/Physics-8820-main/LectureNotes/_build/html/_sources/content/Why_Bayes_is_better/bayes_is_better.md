# Why Bayes is better

In this section we go over nice features of Bayesian statistics.

