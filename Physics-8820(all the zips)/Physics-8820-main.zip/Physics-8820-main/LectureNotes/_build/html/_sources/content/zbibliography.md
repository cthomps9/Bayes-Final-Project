# Bibliography

This is a partial list of good references.


```{bibliography} ../references.bib
```
