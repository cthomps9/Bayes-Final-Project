# Model selection

In this section we go over basic features of Bayesian model selection.

Good references are 
