# Bayesian parameter estimation

In this section we go over basic features of Bayesian statistics.

Good references are Chapters 1 and 2 Sivia {cite}`Sivia2006`; Chapter 1 from Gregory {cite}`Gregory:2005`; 
