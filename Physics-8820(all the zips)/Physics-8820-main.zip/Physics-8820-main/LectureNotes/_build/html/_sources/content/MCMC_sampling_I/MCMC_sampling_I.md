# MCMC Sampling I

In this section we introduce Markov Chain Monte Carlo sampling. (More later.)

Good references 
