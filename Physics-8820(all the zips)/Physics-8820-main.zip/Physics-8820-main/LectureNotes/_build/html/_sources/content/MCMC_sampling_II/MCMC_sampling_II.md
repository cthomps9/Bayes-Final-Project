# MCMC Sampling II

In this section we explore more details of Markov Chain Monte Carlo sampling. 

Good references 
