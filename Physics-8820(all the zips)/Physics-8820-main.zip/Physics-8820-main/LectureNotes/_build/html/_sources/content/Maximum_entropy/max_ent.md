# Maximum entropy

In this section we talk about finding probabilities. Max ent is one type.

Good references are Chapters ??? Sivia {cite}`Sivia2006`; Chapter ?? from Gregory {cite}`Gregory:2005`; 
