# PCA, SVD, and all that

In this section we do PCA, SVD and the like.

Good references are 
